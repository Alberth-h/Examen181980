﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Colisiones : MonoBehaviour {
	public GameObject Puntuaciones;
	private int puntos=0;
	public AudioClip SonidoCoin;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	//Método para saber las colisiones
	void OnTriggerEnter(Collider objeto){
		if (objeto.gameObject.tag== "Moneda") {
			Debug.Log ("Toque moneda");
			gameObject.GetComponent<AudioSource> ().PlayOneShot (SonidoCoin, 0.7f);
			Destroy (objeto.gameObject);
			puntos++;
			Puntuaciones.GetComponent<Text>().text=puntos.ToString();
		}
	}
}
